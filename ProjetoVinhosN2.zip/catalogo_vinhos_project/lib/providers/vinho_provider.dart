// lib/providers/vinho_provider.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/vinho.dart';

class VinhoProvider with ChangeNotifier {
  final List<Vinho> _vinhos = [];

  List<Vinho> get vinhos => [..._vinhos];

  Future<void> fetchVinhos() async {
    final snapshot = await FirebaseFirestore.instance.collection('vinhos').get();
    _vinhos.clear();
    for (var doc in snapshot.docs) {
      _vinhos.add(Vinho.fromMap(doc.data(), doc.id));
    }
    notifyListeners();
  }

  Future<void> adicionarVinho(Vinho vinho) async {
    final docRef = await FirebaseFirestore.instance.collection('vinhos').add(vinho.toMap());
    vinho.id = docRef.id;
    _vinhos.add(vinho);
    notifyListeners();
  }

  Future<void> atualizarVinho(String id, Vinho vinho) async {
    await FirebaseFirestore.instance.collection('vinhos').doc(id).update(vinho.toMap());
    final index = _vinhos.indexWhere((v) => v.id == id);
    if (index >= 0) {
      _vinhos[index] = vinho;
      notifyListeners();
    }
  }

  Future<void> removerVinho(String id) async {
    await FirebaseFirestore.instance.collection('vinhos').doc(id).delete();
    _vinhos.removeWhere((v) => v.id == id);
    notifyListeners();
  }
}
