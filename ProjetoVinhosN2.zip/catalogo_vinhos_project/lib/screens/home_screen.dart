// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/vinho_provider.dart';
import 'add_vinho_screen.dart';
import '../widgets/vinho_item.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Catálogo de Vinhos'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AddVinhoScreen()),
              );
            },
          ),
        ],
      ),
      body: Consumer<VinhoProvider>(
        builder: (ctx, vinhoProvider, _) {
          if (vinhoProvider.vinhos.isEmpty) {
            return Center(
              child: Text('Nenhum vinho adicionado ainda!'),
            );
          } else {
            return ListView.builder(
              itemCount: vinhoProvider.vinhos.length,
              itemBuilder: (ctx, i) {
                final vinho = vinhoProvider.vinhos[i];
                return VinhoItem(vinho: vinho);
              },
            );
          }
        },
      ),
    );
  }
}
