// lib/screens/add_vinho_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/vinho.dart';
import '../providers/vinho_provider.dart';

class AddVinhoScreen extends StatefulWidget {
  final Vinho? vinho;

  AddVinhoScreen({this.vinho});

  @override
  _AddVinhoScreenState createState() => _AddVinhoScreenState();
}

class _AddVinhoScreenState extends State<AddVinhoScreen> {
  final _formKey = GlobalKey<FormState>();
  String _nome = '';
  String _descricao = '';
  String _tipo = '';
  int _ano = DateTime.now().year;

  @override
  void initState() {
    super.initState();
    if (widget.vinho != null) {
      _nome = widget.vinho!.nome;
      _descricao = widget.vinho!.descricao;
      _tipo = widget.vinho!.tipo;
      _ano = widget.vinho!.ano;
    }
  }

  void _saveForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final vinho = Vinho(
        id: widget.vinho?.id ?? DateTime.now().toString(),
        nome: _nome,
        descricao: _descricao,
        tipo: _tipo,
        ano: _ano,
      );
      if (widget.vinho == null) {
        Provider.of<VinhoProvider>(context, listen: false).adicionarVinho(vinho);
      } else {
        Provider.of<VinhoProvider>(context, listen: false)
            .atualizarVinho(widget.vinho!.id, vinho);
      }
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.vinho == null ? 'Adicionar Vinho' : 'Editar Vinho'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                initialValue: _nome,
                decoration: InputDecoration(labelText: 'Nome'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira o nome do vinho';
                  }
                  return null;
                },
                onSaved: (value) => _nome = value!,
              ),
              TextFormField(
                initialValue: _descricao,
                decoration: InputDecoration(labelText: 'Descrição'),
                maxLines: 3,
                onSaved: (value) => _descricao = value!,
              ),
              TextFormField(
                initialValue: _tipo,
                decoration: InputDecoration(labelText: 'Tipo'),
                onSaved: (value) => _tipo = value!,
              ),
              TextFormField(
                initialValue: _ano.toString(),
                decoration: InputDecoration(labelText: 'Ano'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || int.tryParse(value) == null) {
                    return 'Insira um ano válido';
                  }
                  return null;
                },
                onSaved: (value) => _ano = int.parse(value!),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveForm,
                child: Text('Salvar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
