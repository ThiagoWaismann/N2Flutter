// lib/widgets/vinho_item.dart

import 'package:flutter/material.dart';
import '../models/vinho.dart';
import '../providers/vinho_provider.dart';
import 'package:provider/provider.dart';
import '../screens/add_vinho_screen.dart';

class VinhoItem extends StatelessWidget {
  final Vinho vinho;

  VinhoItem({required this.vinho});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        title: Text(vinho.nome),
        subtitle: Text('${vinho.tipo} - ${vinho.ano}'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(Icons.edit),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => AddVinhoScreen(vinho: vinho),
                  ),
                );
              },
            ),
            IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                Provider.of<VinhoProvider>(context, listen: false)
                    .removerVinho(vinho.id);
              },
            ),
          ],
        ),
      ),
    );
  }
}
