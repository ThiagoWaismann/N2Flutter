// lib/models/vinho.dart

class Vinho {
  String id;
  final String nome;
  final String descricao;
  final String tipo;
  final int ano;

  Vinho({
    required this.id,
    required this.nome,
    required this.descricao,
    required this.tipo,
    required this.ano,
  });

  Map<String, dynamic> toMap() {
    return {
      'nome': nome,
      'descricao': descricao,
      'tipo': tipo,
      'ano': ano,
    };
  }

  static Vinho fromMap(Map<String, dynamic> map, String documentId) {
    return Vinho(
      id: documentId,
      nome: map['nome'],
      descricao: map['descricao'],
      tipo: map['tipo'],
      ano: map['ano'],
    );
  }
}
