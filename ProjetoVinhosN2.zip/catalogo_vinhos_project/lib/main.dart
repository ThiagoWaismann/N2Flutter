import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:provider/provider.dart';
import 'providers/vinho_provider.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(CatalogoVinhosApp());
}

class CatalogoVinhosApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => VinhoProvider(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Catálogo de Vinhos',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.brown,
            primary: Color(0xFF3E2723), // Marrom escuro
            secondary: Color(0xFFFFC107), // Âmbar
            background: Color(0xFFF5F5F5), // Cor de fundo suave
          ),
          scaffoldBackgroundColor: Color(0xFFF5F5F5),
          appBarTheme: AppBarTheme(
            backgroundColor: Color(0xFF3E2723),
            titleTextStyle: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            centerTitle: true,
          ),
          textTheme: TextTheme(
            titleLarge: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Color(0xFF3E2723),
            ),
            bodyLarge: TextStyle(
              fontSize: 16,
              color: Color(0xFF5D4037),
            ),
            bodyMedium: TextStyle(
              fontSize: 14,
              color: Color(0xFF5D4037),
            ),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.black, // Cor do texto no botão
              backgroundColor: Color(0xFFFFC107), // Cor de fundo do botão
              padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          cardTheme: CardTheme(
            color: Colors.white,
            shadowColor: Colors.grey.shade300,
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            margin: EdgeInsets.all(8),
          ),
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: HomeScreen(),
      ),
    );
  }
}
